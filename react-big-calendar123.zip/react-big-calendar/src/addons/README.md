### react-big-calendar Addons

Addons are community contributed and maintained additional functionality built on top of the core `react-big-calendar`

* [Drag and Drop](./dragAndDrop/README.md)
