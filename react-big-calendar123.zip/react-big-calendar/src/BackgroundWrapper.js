import NoopWrapper from './NoopWrapper'

export default NoopWrapper
